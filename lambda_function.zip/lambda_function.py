import os
import requests
import json

url = "https://ij92qpvpma.execute-api.eu-west-1.amazonaws.com/candidate-email_serverless_lambda_stage/data"
headers = {
    "X-Siemens-Auth": "test"
}
payload = {
    "subnet_id": os.environ.get("PRIVATE_SUBNET_ID"),
    "name": os.environ.get("FULL_NAME"),
    "email": os.environ.get("EMAIL_ADDRESS")
}

response = requests.post(url, headers=headers, json=payload)

if response.status_code == 200:

    response_data = {
        "StatusCode": response.status_code,
        "LogResult": response.text,
        "ExecutedVersion": "$LATEST"
    }

    
    response_json = json.dumps(response_data)
    print(response_json)  
else:
    print("Request failed with status code:", response.status_code)